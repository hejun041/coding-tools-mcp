#!/usr/bin/env node

/**
 * Result receiver and trigger proxy server for Workspace Agent demos.
 *
 * Supports:
 * 1. Backend trigger proxy: POST /api/trigger
 * 2. Webhook-style result storage: POST /api/agent-results/webhook
 * 3. Frontend SSE updates: GET /api/stream?conversation_key=...
 * 4. Polling fallback: GET /api/agent-results?conversation_key=...
 * 5. Legacy visible push endpoints for MCP compatibility
 *
 * Env:
 *   OPENAI_API_BASE=https://api.chatgpt.com
 *   AGENT_ACCESS_TOKEN=...
 *   AGENT_ACCESS_TOKENS={"agtch_xxx":"token1","default":"token2"}
 */

const http = require('http');
const { URL } = require('url');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 3000);
const PUSH_TOKEN = process.env.PUSH_TOKEN || '';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const HISTORY_LIMIT = Number(process.env.HISTORY_LIMIT || 300);
const OPENAI_API_BASE = (process.env.OPENAI_API_BASE || 'https://api.chatgpt.com').replace(/\/+$/, '');
const AGENT_ACCESS_TOKEN = process.env.AGENT_ACCESS_TOKEN || '';

let AGENT_ACCESS_TOKEN_MAP = null;
try {
  AGENT_ACCESS_TOKEN_MAP = process.env.AGENT_ACCESS_TOKENS ? JSON.parse(process.env.AGENT_ACCESS_TOKENS) : null;
} catch {
  AGENT_ACCESS_TOKEN_MAP = null;
}

const legacyClientsByJobId = new Map();
const legacyHistoryByJobId = new Map();
const resultClientsByConversationKey = new Map();
const runsByConversationKey = new Map();
const jobToConversationKey = new Map();

function now() {
  return new Date().toISOString();
}

function baseHeaders(extra = {}) {
  return {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Last-Event-ID',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    ...extra
  };
}

function json(res, statusCode, payload) {
  res.writeHead(statusCode, baseHeaders({ 'Content-Type': 'application/json; charset=utf-8' }));
  res.end(JSON.stringify(payload, null, 2));
}

function writeNamedSSE(res, eventName, data) {
  if (eventName) res.write(`event: ${eventName}\n`);
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

function writeComment(res, text) {
  res.write(`: ${text}\n\n`);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1024 * 1024) {
        reject(new Error('body_too_large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(raw));
    req.on('error', reject);
  });
}

function isAuthorized(req) {
  if (!PUSH_TOKEN) return true;
  return req.headers.authorization === `Bearer ${PUSH_TOKEN}`;
}

function resolveAgentAccessToken(agentId) {
  if (AGENT_ACCESS_TOKEN_MAP && typeof AGENT_ACCESS_TOKEN_MAP === 'object') {
    if (agentId && AGENT_ACCESS_TOKEN_MAP[agentId]) return String(AGENT_ACCESS_TOKEN_MAP[agentId]);
    if (AGENT_ACCESS_TOKEN_MAP.default) return String(AGENT_ACCESS_TOKEN_MAP.default);
  }
  return AGENT_ACCESS_TOKEN;
}

function getLegacyClients(jobId) {
  if (!legacyClientsByJobId.has(jobId)) legacyClientsByJobId.set(jobId, new Set());
  return legacyClientsByJobId.get(jobId);
}

function getLegacyHistory(jobId) {
  if (!legacyHistoryByJobId.has(jobId)) legacyHistoryByJobId.set(jobId, []);
  return legacyHistoryByJobId.get(jobId);
}

function addLegacyHistory(jobId, item) {
  const history = getLegacyHistory(jobId);
  history.push(item);
  if (history.length > HISTORY_LIMIT) {
    history.splice(0, history.length - HISTORY_LIMIT);
  }
  return history.length;
}

function snapshotLegacy(jobId) {
  return {
    job_id: jobId,
    active_clients: legacyClientsByJobId.get(jobId)?.size || 0,
    event_count: legacyHistoryByJobId.get(jobId)?.length || 0,
    history: legacyHistoryByJobId.get(jobId) || []
  };
}

function emptyRun(conversationKey) {
  return {
    conversation_key: conversationKey,
    delivery_status: 'pending',
    callback_url: '',
    job_ids: [],
    event_count: 0,
    last_event_type: '',
    final_result: '',
    final_time: '',
    done: false,
    error: null,
    images: [],
    events: [],
    updated_at: now(),
    created_at: now()
  };
}

function normalizeEventTitle(type) {
  const mapping = {
    status: '状态',
    reasoning: '过程摘要',
    tool: '工具事件',
    delta: '阶段结果',
    final: '最终结果',
    error: '错误',
    system: '系统',
    user: '用户请求',
    webhook: 'Webhook'
  };
  return mapping[type] || type;
}

function getOrCreateRun(conversationKey) {
  if (!runsByConversationKey.has(conversationKey)) {
    runsByConversationKey.set(conversationKey, emptyRun(conversationKey));
  }
  return runsByConversationKey.get(conversationKey);
}

function trimRunEvents(run) {
  if (run.events.length > HISTORY_LIMIT) {
    run.events.splice(0, run.events.length - HISTORY_LIMIT);
  }
  run.event_count = run.events.length;
}

function attachJobToRun(run, jobId) {
  if (jobId && !run.job_ids.includes(jobId)) {
    run.job_ids.push(jobId);
  }
}

function extractImages(source) {
  if (!source) return [];
  if (Array.isArray(source)) return source.filter(Boolean);
  if (Array.isArray(source.images)) return source.images.filter(Boolean);
  return [];
}

function makeStreamPayload(run, reason, extra = {}) {
  return {
    reason,
    run,
    ...extra,
    ts: now()
  };
}

function getResultClients(conversationKey) {
  if (!resultClientsByConversationKey.has(conversationKey)) {
    resultClientsByConversationKey.set(conversationKey, new Set());
  }
  return resultClientsByConversationKey.get(conversationKey);
}

function broadcastRunSnapshot(conversationKey, reason, extra = {}) {
  if (!conversationKey) return;
  const run = runsByConversationKey.get(conversationKey);
  const clients = resultClientsByConversationKey.get(conversationKey);
  if (!run || !clients?.size) return;
  const payload = makeStreamPayload(run, reason, extra);
  for (const res of clients) {
    writeNamedSSE(res, 'result', payload);
  }
}

function storeEventForRun({ conversationKey, jobId, type, payload }) {
  if (!conversationKey) return null;
  const run = getOrCreateRun(conversationKey);
  attachJobToRun(run, jobId);
  run.last_event_type = type;
  run.updated_at = payload.ts || now();

  const text = payload.result || payload.text || payload.message || '';
  const images = extractImages(payload);
  run.events.push({
    type,
    title: normalizeEventTitle(type),
    text,
    payload,
    images,
    time: payload.ts || now(),
    job_id: jobId || null
  });

  if (payload.callback_url) run.callback_url = payload.callback_url;
  if (images.length) run.images = images;

  if (type === 'final') {
    run.final_result = payload.result || payload.text || payload.message || run.final_result;
    run.final_time = payload.ts || now();
    run.delivery_status = 'completed';
    run.done = true;
    run.error = null;
  } else if (type === 'error') {
    run.delivery_status = payload.fatal ? 'failed' : 'warning';
    run.error = payload.message || payload.text || 'unknown_error';
    if (payload.fatal) run.done = true;
  } else if (type === 'status' && run.delivery_status === 'accepted') {
    run.delivery_status = 'in_progress';
  } else if (!run.done) {
    run.delivery_status = 'in_progress';
  }

  trimRunEvents(run);
  return run;
}

function markAccepted({ conversationKey, jobId, callbackUrl, prompt }) {
  if (!conversationKey) return null;
  const run = getOrCreateRun(conversationKey);
  attachJobToRun(run, jobId);
  if (callbackUrl) run.callback_url = callbackUrl;
  run.delivery_status = 'accepted';
  run.done = false;
  run.updated_at = now();

  if (prompt) {
    run.events.push({
      type: 'user',
      title: '用户请求',
      text: prompt,
      payload: { prompt },
      images: [],
      time: now(),
      job_id: jobId || null
    });
  }

  run.events.push({
    type: 'system',
    title: '系统',
    text: '任务已提交到 Trigger API，等待 webhook 或 MCP 回调结果。',
    payload: { callback_url: callbackUrl || '' },
    images: [],
    time: now(),
    job_id: jobId || null
  });
  trimRunEvents(run);
  return run;
}

function broadcastLegacy(jobId, type, data) {
  const payload = { ...data, job_id: jobId, ts: now() };
  payload.seq = addLegacyHistory(jobId, { type, data: payload, ts: payload.ts });

  const clients = legacyClientsByJobId.get(jobId);
  if (clients?.size) {
    for (const res of clients) writeNamedSSE(res, type, payload);
  }
  return payload;
}

function closeLegacyJob(jobId) {
  const clients = legacyClientsByJobId.get(jobId);
  if (!clients) return;
  for (const res of clients) {
    try { res.end(); } catch (_) {}
  }
  legacyClientsByJobId.delete(jobId);
}

function handleLegacySSE(req, res, urlObj) {
  const jobId = (urlObj.searchParams.get('job_id') || '').trim();
  if (!jobId) return json(res, 400, { ok: false, error: 'missing_job_id' });

  res.writeHead(200, baseHeaders({
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no'
  }));

  res.write('retry: 3000\n');
  writeComment(res, 'connected');
  writeNamedSSE(res, 'status', {
    job_id: jobId,
    message: 'SSE connected',
    note: 'reasoning events are visible summaries, not hidden chain-of-thought',
    ts: now()
  });

  for (const item of getLegacyHistory(jobId)) writeNamedSSE(res, item.type, item.data);

  const clients = getLegacyClients(jobId);
  clients.add(res);

  const heartbeat = setInterval(() => {
    try { writeComment(res, `heartbeat ${Date.now()}`); } catch (_) { clearInterval(heartbeat); }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    clients.delete(res);
    if (clients.size === 0) legacyClientsByJobId.delete(jobId);
  });
}

function handleResultSSE(req, res, urlObj) {
  const conversationKey = (urlObj.searchParams.get('conversation_key') || '').trim();
  if (!conversationKey) return json(res, 400, { ok: false, error: 'missing_conversation_key' });

  res.writeHead(200, baseHeaders({
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no'
  }));

  res.write('retry: 2000\n');
  writeComment(res, 'connected');

  const run = runsByConversationKey.get(conversationKey) || emptyRun(conversationKey);
  writeNamedSSE(res, 'result', makeStreamPayload(run, 'connected'));

  const clients = getResultClients(conversationKey);
  clients.add(res);

  const heartbeat = setInterval(() => {
    try { writeComment(res, `heartbeat ${Date.now()}`); } catch (_) { clearInterval(heartbeat); }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    clients.delete(res);
    if (clients.size === 0) resultClientsByConversationKey.delete(conversationKey);
  });
}

async function handleTrigger(req, res) {
  let raw;
  try {
    raw = await readBody(req);
  } catch (error) {
    return json(res, 413, { ok: false, error: error.message || 'read_body_failed' });
  }

  let payload;
  try {
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    return json(res, 400, { ok: false, error: 'invalid_json' });
  }

  const agentId = String(payload.agentId || payload.agent_id || '').trim();
  const prompt = String(payload.prompt || payload.input || '').trim();
  const conversationKey = String(payload.conversationKey || payload.conversation_key || '').trim();
  const idempotencyKey = String(payload.idempotencyKey || payload.idempotency_key || '').trim() || `idem_${Date.now()}`;
  const token = resolveAgentAccessToken(agentId);

  if (!agentId) return json(res, 400, { ok: false, error: 'missing_agent_id' });
  if (!token) return json(res, 500, { ok: false, error: 'missing_server_side_agent_access_token' });
  if (!prompt) return json(res, 400, { ok: false, error: 'missing_prompt' });
  if (!conversationKey) return json(res, 400, { ok: false, error: 'missing_conversation_key' });

  try {
    const response = await fetch(`${OPENAI_API_BASE}/v1/workspace_agents/${agentId}/trigger`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Idempotency-Key': idempotencyKey
      },
      body: JSON.stringify({
        conversation_key: conversationKey,
        input: prompt
      })
    });

    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch {}

    if (response.status !== 202) {
      return json(res, response.status, {
        ok: false,
        error: 'trigger_failed',
        status: response.status,
        body: data || text || null
      });
    }

    const callbackUrl = data?.conversation_url || '';
    const jobId = String(data?.job_id || '').trim();
    if (jobId) jobToConversationKey.set(jobId, conversationKey);
    const run = markAccepted({ conversationKey, jobId, callbackUrl, prompt });
    broadcastRunSnapshot(conversationKey, 'accepted');

    return json(res, 200, {
      ok: true,
      status: 'accepted',
      agent_id: agentId,
      conversation_key: conversationKey,
      idempotency_key: idempotencyKey,
      callback_url: callbackUrl,
      job_id: jobId || null,
      run
    });
  } catch (error) {
    return json(res, 500, {
      ok: false,
      error: 'trigger_request_failed',
      message: error.message || String(error)
    });
  }
}

async function handlePush(req, res) {
  if (!isAuthorized(req)) return json(res, 401, { ok: false, error: 'unauthorized' });

  let raw;
  try {
    raw = await readBody(req);
  } catch (error) {
    return json(res, 413, { ok: false, error: error.message || 'read_body_failed' });
  }

  let payload;
  try {
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    return json(res, 400, { ok: false, error: 'invalid_json' });
  }

  const type = String(payload.type || '').trim();
  const allowed = new Set(['status', 'reasoning', 'tool', 'delta', 'final', 'error', 'webhook']);
  if (!type) return json(res, 400, { ok: false, error: 'missing_type' });
  if (!allowed.has(type)) return json(res, 400, { ok: false, error: 'invalid_type', allowed: [...allowed] });

  const jobId = String(payload.job_id || '').trim();
  const conversationKey = String(payload.conversation_key || payload.run_key || jobToConversationKey.get(jobId) || '').trim();
  const callbackUrl = String(payload.callback_url || '').trim();
  if (!jobId && !conversationKey) {
    return json(res, 400, { ok: false, error: 'missing_job_id_or_conversation_key' });
  }

  if (jobId && conversationKey) jobToConversationKey.set(jobId, conversationKey);

  const eventData = {
    conversation_key: conversationKey || undefined,
    callback_url: callbackUrl || undefined,
    message: payload.message,
    text: payload.text,
    result: payload.result,
    meta: payload.meta || null,
    images: extractImages(payload),
    fatal: payload.fatal === true
  };

  let sent = null;
  if (jobId) sent = broadcastLegacy(jobId, type, eventData);
  else sent = { ...eventData, ts: now(), seq: null };

  const run = storeEventForRun({ conversationKey, jobId, type, payload: sent });
  if (run) broadcastRunSnapshot(conversationKey, 'event', { event_type: type });

  if (payload.close === true || type === 'final' || (type === 'error' && payload.fatal === true)) {
    if (jobId) setTimeout(() => closeLegacyJob(jobId), 500);
  }

  return json(res, 200, {
    ok: true,
    job_id: jobId || null,
    conversation_key: conversationKey || null,
    type,
    seq: sent.seq,
    active_clients: jobId ? (legacyClientsByJobId.get(jobId)?.size || 0) : 0,
    delivery_status: run?.delivery_status || null
  });
}

async function handleWebhook(req, res) {
  if (!isAuthorized(req)) return json(res, 401, { ok: false, error: 'unauthorized' });

  let raw;
  try {
    raw = await readBody(req);
  } catch (error) {
    return json(res, 413, { ok: false, error: error.message || 'read_body_failed' });
  }

  let payload;
  try {
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    return json(res, 400, { ok: false, error: 'invalid_json' });
  }

  const conversationKey = String(payload.conversation_key || payload.run_key || '').trim();
  if (!conversationKey) return json(res, 400, { ok: false, error: 'missing_conversation_key' });

  const run = getOrCreateRun(conversationKey);
  const callbackUrl = String(payload.callback_url || payload.conversation_url || '').trim();
  const jobId = String(payload.job_id || '').trim();
  if (jobId) jobToConversationKey.set(jobId, conversationKey);
  attachJobToRun(run, jobId);
  if (callbackUrl) run.callback_url = callbackUrl;

  const incomingEvents = Array.isArray(payload.events) ? payload.events : [];
  if (incomingEvents.length) {
    run.events = incomingEvents.map((item, index) => ({
      type: String(item.type || 'webhook'),
      title: item.title || normalizeEventTitle(String(item.type || 'webhook')),
      text: item.text || item.message || item.summary || item.result || JSON.stringify(item.payload || item),
      payload: item.payload || item,
      images: extractImages(item),
      time: item.time || item.created_at || item.timestamp || now(),
      index,
      job_id: item.job_id || jobId || null
    }));
  } else if (payload.final_result || payload.result || payload.error) {
    run.events.push({
      type: payload.error ? 'error' : 'final',
      title: payload.error ? '错误' : '最终结果',
      text: payload.final_result || payload.result || payload.error || '',
      payload,
      images: extractImages(payload),
      time: payload.updated_at || now(),
      job_id: jobId || null
    });
  }

  run.images = extractImages(payload);
  run.final_result = payload.final_result || payload.result || run.final_result || '';
  run.final_time = payload.final_time || payload.updated_at || now();
  run.error = payload.error || null;
  run.delivery_status = payload.delivery_status || payload.status || (run.final_result ? 'completed' : 'in_progress');
  run.done = payload.done === true || payload.completed === true || /done|complete|completed|finished|final/i.test(run.delivery_status) || !!run.final_result;
  run.last_event_type = payload.last_event_type || run.events.at(-1)?.type || run.last_event_type || '';
  run.updated_at = payload.updated_at || now();
  trimRunEvents(run);

  broadcastRunSnapshot(conversationKey, 'webhook');

  return json(res, 200, {
    ok: true,
    conversation_key: conversationKey,
    delivery_status: run.delivery_status,
    event_count: run.event_count,
    done: run.done
  });
}

function handleResults(req, res, urlObj) {
  const conversationKey = String(urlObj.searchParams.get('conversation_key') || '').trim();
  const jobId = String(urlObj.searchParams.get('job_id') || '').trim();

  let run = null;
  if (conversationKey) run = runsByConversationKey.get(conversationKey) || null;
  if (!run && jobId) {
    const mappedConversationKey = jobToConversationKey.get(jobId);
    if (mappedConversationKey) run = runsByConversationKey.get(mappedConversationKey) || null;
  }

  if (!run) {
    return json(res, 200, {
      ok: true,
      conversation_key: conversationKey || null,
      delivery_status: 'pending',
      done: false,
      event_count: 0,
      events: []
    });
  }

  return json(res, 200, { ok: true, ...run });
}

async function handleAccept(req, res) {
  if (!isAuthorized(req)) return json(res, 401, { ok: false, error: 'unauthorized' });

  let raw;
  try {
    raw = await readBody(req);
  } catch (error) {
    return json(res, 413, { ok: false, error: error.message || 'read_body_failed' });
  }

  let payload;
  try {
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    return json(res, 400, { ok: false, error: 'invalid_json' });
  }

  const conversationKey = String(payload.conversation_key || '').trim();
  const jobId = String(payload.job_id || '').trim();
  const callbackUrl = String(payload.callback_url || payload.conversation_url || '').trim();
  const prompt = String(payload.prompt || '').trim();

  if (!conversationKey) return json(res, 400, { ok: false, error: 'missing_conversation_key' });
  if (jobId) jobToConversationKey.set(jobId, conversationKey);

  const run = markAccepted({ conversationKey, jobId, callbackUrl, prompt });
  broadcastRunSnapshot(conversationKey, 'accepted');
  return json(res, 200, { ok: true, ...run });
}

const server = http.createServer(async (req, res) => {
  const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'OPTIONS') {
    res.writeHead(204, baseHeaders());
    return res.end();
  }

  if (req.method === 'GET' && urlObj.pathname === '/healthz') {
    return json(res, 200, {
      ok: true,
      service: 'agent-sse-server',
      host: HOST,
      port: PORT,
      now: now(),
      openai_api_base: OPENAI_API_BASE,
      has_default_agent_access_token: Boolean(AGENT_ACCESS_TOKEN),
      has_agent_access_token_map: Boolean(AGENT_ACCESS_TOKEN_MAP),
      active_jobs: legacyClientsByJobId.size,
      tracked_runs: runsByConversationKey.size,
      result_streams: resultClientsByConversationKey.size
    });
  }

  if (req.method === 'POST' && urlObj.pathname === '/api/trigger') {
    return handleTrigger(req, res);
  }

  if (req.method === 'GET' && urlObj.pathname === '/api/stream') {
    return handleResultSSE(req, res, urlObj);
  }

  if (req.method === 'GET' && urlObj.pathname === '/api/agent-events') {
    return handleLegacySSE(req, res, urlObj);
  }

  if (req.method === 'GET' && urlObj.pathname === '/api/agent-events/history') {
    const jobId = (urlObj.searchParams.get('job_id') || '').trim();
    if (!jobId) return json(res, 400, { ok: false, error: 'missing_job_id' });
    return json(res, 200, { ok: true, ...snapshotLegacy(jobId) });
  }

  if (req.method === 'POST' && urlObj.pathname === '/api/agent-events/push') {
    return handlePush(req, res);
  }

  if (req.method === 'POST' && urlObj.pathname === '/api/agent-results/accept') {
    return handleAccept(req, res);
  }

  if (req.method === 'POST' && urlObj.pathname === '/api/agent-results/webhook') {
    return handleWebhook(req, res);
  }

  if (req.method === 'GET' && urlObj.pathname === '/api/agent-results') {
    return handleResults(req, res, urlObj);
  }

  if (req.method === 'GET' && urlObj.pathname === '/') {
    return json(res, 200, {
      ok: true,
      service: 'agent-sse-server',
      note: 'supports backend trigger proxy, webhook result storage, SSE result streaming, and legacy MCP push compatibility',
      endpoints: {
        healthz: 'GET /healthz',
        trigger: 'POST /api/trigger',
        stream: 'GET /api/stream?conversation_key=conv_xxx',
        results: 'GET /api/agent-results?conversation_key=conv_xxx',
        accept: 'POST /api/agent-results/accept',
        webhook: 'POST /api/agent-results/webhook',
        legacy_sse: 'GET /api/agent-events?job_id=job_xxx',
        legacy_push: 'POST /api/agent-events/push'
      }
    });
  }

  return json(res, 404, { ok: false, error: 'not_found' });
});

server.listen(PORT, HOST, () => {
  console.log(`agent-sse-server listening on http://${HOST}:${PORT}`);
  console.log(`Trigger proxy:     http://${HOST}:${PORT}/api/trigger`);
  console.log(`Result SSE:        http://${HOST}:${PORT}/api/stream?conversation_key=conv_demo`);
  console.log(`Result query:      http://${HOST}:${PORT}/api/agent-results?conversation_key=conv_demo`);
  console.log(`Webhook sink:      http://${HOST}:${PORT}/api/agent-results/webhook`);
  console.log(`Legacy push sink:  http://${HOST}:${PORT}/api/agent-events/push`);
  console.log(`Token source:      ${AGENT_ACCESS_TOKEN_MAP ? 'AGENT_ACCESS_TOKENS map' : (AGENT_ACCESS_TOKEN ? 'AGENT_ACCESS_TOKEN default' : 'missing')}`);
  console.log(`Push auth:         ${PUSH_TOKEN ? 'Bearer token required' : 'disabled (set PUSH_TOKEN to enable)'}`);
});