#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT_DIR="${KIT_DIR:-$SCRIPT_DIR/.runtime}"
PROJECT_DIR="${1:-${PROJECT_DIR:-}}"

HOST="${HOST:-127.0.0.1}"
CODING_TOOLS_MCP_PORT="${CODING_TOOLS_MCP_PORT:-8876}"
RESULT_SERVER_PORT="${RESULT_SERVER_PORT:-3000}"
CALLBACK_MCP_PORT="${CALLBACK_MCP_PORT:-8788}"

CODING_TOOLS_MCP_AUTH_TOKEN="${CODING_TOOLS_MCP_AUTH_TOKEN:-}"
CALLBACK_MCP_AUTH_TOKEN="${CALLBACK_MCP_AUTH_TOKEN:-}"
RESULT_PUSH_TOKEN="${RESULT_PUSH_TOKEN:-${SSE_PUSH_TOKEN:-$CALLBACK_MCP_AUTH_TOKEN}}"
CLOUDFLARE_TUNNEL_TOKEN="${CLOUDFLARE_TUNNEL_TOKEN:-}"

AGENT_ACCESS_TOKEN="${AGENT_ACCESS_TOKEN:-}"
AGENT_ACCESS_TOKENS="${AGENT_ACCESS_TOKENS:-}"
OPENAI_API_BASE="${OPENAI_API_BASE:-https://api.chatgpt.com}"

PUBLIC_CODING_TOOLS_URL="${PUBLIC_CODING_TOOLS_URL:-}"
PUBLIC_CALLBACK_MCP_URL="${PUBLIC_CALLBACK_MCP_URL:-}"
PUBLIC_RESULT_SERVER_BASE_URL="${PUBLIC_RESULT_SERVER_BASE_URL:-${PUBLIC_SSE_BASE_URL:-}}"

LOCAL_RESULT_SERVER_BASE_URL="http://${HOST}:${RESULT_SERVER_PORT}"
LOCAL_CALLBACK_MCP_URL="http://${HOST}:${CALLBACK_MCP_PORT}/mcp"
LOCAL_CODING_TOOLS_MCP_URL="http://${HOST}:${CODING_TOOLS_MCP_PORT}/mcp"

LOG_DIR="$KIT_DIR/logs"
PID_DIR="$KIT_DIR/pids"
NODE_MODULES_DIR="$SCRIPT_DIR/node_modules"

require_env() {
  local name="$1"
  if [[ -z "${!name:-}" ]]; then
    echo "Missing required env: $name" >&2
    exit 1
  fi
}

require_one_of() {
  local first="$1"
  local second="$2"
  if [[ -z "${!first:-}" && -z "${!second:-}" ]]; then
    echo "Missing required env: set either $first or $second" >&2
    exit 1
  fi
}

ensure_command() {
  local command_name="$1"
  local install_hint="$2"
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "$command_name not found. $install_hint" >&2
    exit 1
  fi
}

kill_if_running() {
  local pid_file="$1"
  if [[ -f "$pid_file" ]] && kill -0 "$(cat "$pid_file")" 2>/dev/null; then
    kill "$(cat "$pid_file")" || true
  fi
  rm -f "$pid_file"
}

wait_http() {
  local url="$1"
  local label="$2"
  for _ in {1..60}; do
    if curl -fsS "$url" >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.5
  done
  echo "$label did not become ready: $url" >&2
  exit 1
}

install_node_deps() {
  if [[ -d "$NODE_MODULES_DIR/@modelcontextprotocol" ]] && [[ -d "$NODE_MODULES_DIR/zod" ]]; then
    return 0
  fi

  echo "Installing Node dependencies for remote MCP callback server..."
  (
    cd "$SCRIPT_DIR"
    npm install --no-save @modelcontextprotocol/sdk zod
  )
}

start_background() {
  local name="$1"
  local pid_file="$2"
  local log_file="$3"
  shift 3

  echo "Starting $name ..."
  "$@" > "$log_file" 2>&1 &
  echo $! > "$pid_file"
}

if [[ -z "$PROJECT_DIR" ]]; then
  read -r -p "Project directory to expose to Coding Tools MCP: " PROJECT_DIR
fi
if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Project directory does not exist: $PROJECT_DIR" >&2
  exit 1
fi

require_env CODING_TOOLS_MCP_AUTH_TOKEN
require_env CALLBACK_MCP_AUTH_TOKEN
require_env RESULT_PUSH_TOKEN
require_one_of AGENT_ACCESS_TOKEN AGENT_ACCESS_TOKENS

mkdir -p "$LOG_DIR" "$PID_DIR"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

ensure_command node "Please install Node.js 18+ first."
ensure_command npm "Please install npm first."

if ! command -v uvx >/dev/null 2>&1; then
  echo "uvx not found. Installing uv..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi

if [[ -n "$CLOUDFLARE_TUNNEL_TOKEN" ]]; then
  if ! command -v cloudflared >/dev/null 2>&1; then
    if command -v brew >/dev/null 2>&1; then
      echo "cloudflared not found. Installing with Homebrew..."
      brew install cloudflared
    else
      echo "cloudflared not found. Please install Homebrew, then run: brew install cloudflared" >&2
      exit 1
    fi
  fi
fi

install_node_deps

kill_if_running "$PID_DIR/coding-tools-mcp.pid"
kill_if_running "$PID_DIR/agent-sse-server.pid"
kill_if_running "$PID_DIR/agent-sse-mcp-server.pid"
kill_if_running "$PID_DIR/cloudflared.pid"

export CODING_TOOLS_MCP_AUTH_TOKEN
start_background \
  "Coding Tools MCP" \
  "$PID_DIR/coding-tools-mcp.pid" \
  "$LOG_DIR/coding-tools-mcp.log" \
  uvx coding-tools-mcp \
    --workspace "$PROJECT_DIR" \
    --host "$HOST" \
    --port "$CODING_TOOLS_MCP_PORT" \
    --auth-token "$CODING_TOOLS_MCP_AUTH_TOKEN" \
    --tool-profile full \
    --permission-mode trusted
wait_http "http://${HOST}:${CODING_TOOLS_MCP_PORT}/.well-known/mcp.json" "Coding Tools MCP"

start_background \
  "Result server" \
  "$PID_DIR/agent-sse-server.pid" \
  "$LOG_DIR/agent-sse-server.log" \
  env \
    HOST="$HOST" \
    PORT="$RESULT_SERVER_PORT" \
    PUSH_TOKEN="$RESULT_PUSH_TOKEN" \
    OPENAI_API_BASE="$OPENAI_API_BASE" \
    AGENT_ACCESS_TOKEN="$AGENT_ACCESS_TOKEN" \
    AGENT_ACCESS_TOKENS="$AGENT_ACCESS_TOKENS" \
    node "$SCRIPT_DIR/agent-sse-server.js"
wait_http "http://${HOST}:${RESULT_SERVER_PORT}/healthz" "Result server"

start_background \
  "Remote callback MCP server" \
  "$PID_DIR/agent-sse-mcp-server.pid" \
  "$LOG_DIR/agent-sse-mcp-server.log" \
  env \
    HOST="$HOST" \
    PORT="$CALLBACK_MCP_PORT" \
    CALLBACK_MCP_AUTH_TOKEN="$CALLBACK_MCP_AUTH_TOKEN" \
    RESULT_SERVER_BASE_URL="$LOCAL_RESULT_SERVER_BASE_URL" \
    RESULT_PUSH_TOKEN="$RESULT_PUSH_TOKEN" \
    PUBLIC_MCP_URL="$PUBLIC_CALLBACK_MCP_URL" \
    node "$SCRIPT_DIR/agent-sse-mcp-server.js"
wait_http "http://${HOST}:${CALLBACK_MCP_PORT}/healthz" "Remote callback MCP server"

if [[ -n "$CLOUDFLARE_TUNNEL_TOKEN" ]]; then
  start_background \
    "Cloudflare Tunnel" \
    "$PID_DIR/cloudflared.pid" \
    "$LOG_DIR/cloudflared.log" \
    cloudflared tunnel run --token "$CLOUDFLARE_TUNNEL_TOKEN"
fi

cat <<INFO

✅ Local services are running.

Project:
  $PROJECT_DIR

Local endpoints:
  Coding Tools MCP:   $LOCAL_CODING_TOOLS_MCP_URL
  Callback MCP:       $LOCAL_CALLBACK_MCP_URL
  Result Base URL:    $LOCAL_RESULT_SERVER_BASE_URL
  Trigger Proxy:      $LOCAL_RESULT_SERVER_BASE_URL/api/trigger
  Result SSE:         $LOCAL_RESULT_SERVER_BASE_URL/api/stream?conversation_key=conv_demo
  Result Query:       $LOCAL_RESULT_SERVER_BASE_URL/api/agent-results?conversation_key=conv_demo
  Webhook Sink:       $LOCAL_RESULT_SERVER_BASE_URL/api/agent-results/webhook
  Legacy Push:        $LOCAL_RESULT_SERVER_BASE_URL/api/agent-events/push

Auth:
  Coding Tools MCP token:   $CODING_TOOLS_MCP_AUTH_TOKEN
  Callback MCP token:       $CALLBACK_MCP_AUTH_TOKEN
  Result push token:        $RESULT_PUSH_TOKEN

Trigger auth source:
  OPENAI_API_BASE        = $OPENAI_API_BASE
  AGENT_ACCESS_TOKEN     = ${AGENT_ACCESS_TOKEN:+<set>}${AGENT_ACCESS_TOKEN:-<empty>}
  AGENT_ACCESS_TOKENS    = ${AGENT_ACCESS_TOKENS:+<set>}${AGENT_ACCESS_TOKENS:-<empty>}

Cloudflare public URLs (set these envs before running if you already know them):
  PUBLIC_CODING_TOOLS_URL      = ${PUBLIC_CODING_TOOLS_URL:-<set-on-server>}
  PUBLIC_CALLBACK_MCP_URL      = ${PUBLIC_CALLBACK_MCP_URL:-<set-on-server>}
  PUBLIC_RESULT_SERVER_BASE_URL = ${PUBLIC_RESULT_SERVER_BASE_URL:-<set-on-server>}

Expected Cloudflare or reverse-proxy routing:
  - /mcp -> ${HOST}:${CALLBACK_MCP_PORT}
  - /.well-known/mcp.json -> ${HOST}:${CALLBACK_MCP_PORT}
  - /api/* -> ${HOST}:${RESULT_SERVER_PORT}
  - /healthz -> ${HOST}:${RESULT_SERVER_PORT}
  - static HTML -> your web root

Files used by this launcher:
  $SCRIPT_DIR/agent-sse-server.js
  $SCRIPT_DIR/agent-sse-mcp-server.js

Logs:
  $LOG_DIR/coding-tools-mcp.log
  $LOG_DIR/agent-sse-server.log
  $LOG_DIR/agent-sse-mcp-server.log
  $LOG_DIR/cloudflared.log

Next steps:
  1. Expose the callback MCP and result server endpoints through Cloudflare Tunnel or reverse proxy.
  2. In ChatGPT Custom MCP, use PUBLIC_CALLBACK_MCP_URL + Callback MCP token.
  3. In Agent Webhook Destination, use PUBLIC_RESULT_SERVER_BASE_URL/api/agent-results/webhook.
  4. Open the HTML page from the same public domain that serves /api/trigger and /api/stream.

INFO

wait