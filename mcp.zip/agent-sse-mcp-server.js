#!/usr/bin/env node

/**
 * Remote HTTP MCP callback server for agent result delivery.
 *
 * Compatible with both:
 * - legacy push_status / push_reasoning / push_delta / push_final style tools
 * - webhook-style result aggregation keyed by conversation_key
 */

const http = require('http');
const { URL } = require('url');
const { randomUUID } = require('crypto');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 8788);
const CALLBACK_MCP_AUTH_TOKEN = process.env.CALLBACK_MCP_AUTH_TOKEN || '';
const RESULT_SERVER_BASE_URL = (process.env.RESULT_SERVER_BASE_URL || 'http://127.0.0.1:3000').replace(/\/+$/, '');
const RESULT_PUSH_TOKEN = process.env.RESULT_PUSH_TOKEN || '';
const PUBLIC_MCP_URL = process.env.PUBLIC_MCP_URL || '';
const LEGACY_PUSH_ENDPOINT = `${RESULT_SERVER_BASE_URL}/api/agent-events/push`;
const WEBHOOK_ENDPOINT = `${RESULT_SERVER_BASE_URL}/api/agent-results/webhook`;
const ACCEPT_ENDPOINT = `${RESULT_SERVER_BASE_URL}/api/agent-results/accept`;

function now() {
  return new Date().toISOString();
}

function json(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, mcp-session-id',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS'
  });
  res.end(JSON.stringify(payload, null, 2));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 2 * 1024 * 1024) {
        reject(new Error('body_too_large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(raw));
    req.on('error', reject);
  });
}

function isAuthorized(req) {
  if (!CALLBACK_MCP_AUTH_TOKEN) return true;
  return req.headers.authorization === `Bearer ${CALLBACK_MCP_AUTH_TOKEN}`;
}

async function postJson(url, payload) {
  const headers = { 'Content-Type': 'application/json' };
  if (RESULT_PUSH_TOKEN) headers.Authorization = `Bearer ${RESULT_PUSH_TOKEN}`;

  const resp = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload)
  });

  const raw = await resp.text();
  let data;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = raw;
  }

  if (!resp.ok) {
    throw new Error(`push_failed_http_${resp.status}: ${typeof data === 'string' ? data : JSON.stringify(data)}`);
  }
  return data;
}

function normalizeKeys({ conversation_key, job_id }) {
  return {
    conversation_key: String(conversation_key || '').trim(),
    job_id: String(job_id || '').trim()
  };
}

async function pushLegacyEvent({ conversation_key, job_id, type, message, text, result, meta = null, close = false, fatal = false, callback_url = '' }) {
  const ids = normalizeKeys({ conversation_key, job_id });
  if (!ids.conversation_key && !ids.job_id) {
    throw new Error('missing_conversation_key_or_job_id');
  }
  return postJson(LEGACY_PUSH_ENDPOINT, {
    ...ids,
    type,
    message,
    text,
    result,
    meta,
    close,
    fatal,
    callback_url
  });
}

async function acceptRun({ conversation_key, job_id, callback_url = '' }) {
  const ids = normalizeKeys({ conversation_key, job_id });
  if (!ids.conversation_key) throw new Error('missing_conversation_key');
  return postJson(ACCEPT_ENDPOINT, {
    ...ids,
    callback_url
  });
}

async function sendWebhookResult({ conversation_key, job_id, callback_url = '', delivery_status = 'completed', final_result = '', error = null, done = true, events = [] }) {
  const ids = normalizeKeys({ conversation_key, job_id });
  if (!ids.conversation_key) throw new Error('missing_conversation_key');
  return postJson(WEBHOOK_ENDPOINT, {
    ...ids,
    callback_url,
    delivery_status,
    final_result,
    error,
    done,
    updated_at: now(),
    events
  });
}

function createToolServer(McpServer, z) {
  const server = new McpServer({
    name: 'agent-result-callback-tools',
    version: '3.0.0'
  });

  const okText = (text) => ({ content: [{ type: 'text', text }] });
  const errorText = (message) => ({ content: [{ type: 'text', text: `Error: ${message}` }], isError: true });

  const keyedSchema = {
    conversation_key: z.string().optional(),
    job_id: z.string().optional()
  };

  server.tool(
    'mark_run_accepted',
    {
      conversation_key: z.string().min(1),
      job_id: z.string().optional(),
      callback_url: z.string().optional()
    },
    async ({ conversation_key, job_id, callback_url }) => {
      try {
        await acceptRun({ conversation_key, job_id, callback_url: callback_url || '' });
        return okText(`run accepted for ${conversation_key}`);
      } catch (error) {
        return errorText(error.message || 'failed to mark run accepted');
      }
    }
  );

  server.tool(
    'push_status',
    {
      ...keyedSchema,
      message: z.string().min(1),
      meta: z.record(z.any()).optional()
    },
    async ({ conversation_key, job_id, message, meta }) => {
      try {
        await pushLegacyEvent({ conversation_key, job_id, type: 'status', message, meta: meta || null });
        return okText(`status sent`);
      } catch (error) {
        return errorText(error.message || 'failed to send status');
      }
    }
  );

  server.tool(
    'push_reasoning',
    {
      ...keyedSchema,
      message: z.string().min(1),
      meta: z.record(z.any()).optional()
    },
    async ({ conversation_key, job_id, message, meta }) => {
      try {
        await pushLegacyEvent({ conversation_key, job_id, type: 'reasoning', message, meta: meta || null });
        return okText(`reasoning summary sent`);
      } catch (error) {
        return errorText(error.message || 'failed to send reasoning summary');
      }
    }
  );

  server.tool(
    'push_tool',
    {
      ...keyedSchema,
      message: z.string().min(1),
      meta: z.record(z.any()).optional()
    },
    async ({ conversation_key, job_id, message, meta }) => {
      try {
        await pushLegacyEvent({ conversation_key, job_id, type: 'tool', message, meta: meta || null });
        return okText(`tool event sent`);
      } catch (error) {
        return errorText(error.message || 'failed to send tool event');
      }
    }
  );

  server.tool(
    'push_delta',
    {
      ...keyedSchema,
      text: z.string().min(1),
      meta: z.record(z.any()).optional()
    },
    async ({ conversation_key, job_id, text, meta }) => {
      try {
        await pushLegacyEvent({ conversation_key, job_id, type: 'delta', text, meta: meta || null });
        return okText(`delta sent`);
      } catch (error) {
        return errorText(error.message || 'failed to send delta');
      }
    }
  );

  server.tool(
    'push_final',
    {
      ...keyedSchema,
      result: z.string().min(1),
      meta: z.record(z.any()).optional(),
      close: z.boolean().optional()
    },
    async ({ conversation_key, job_id, result, meta, close }) => {
      try {
        await pushLegacyEvent({
          conversation_key,
          job_id,
          type: 'final',
          result,
          meta: meta || null,
          close: close ?? true
        });
        return okText(`final result sent`);
      } catch (error) {
        return errorText(error.message || 'failed to send final result');
      }
    }
  );

  server.tool(
    'push_error',
    {
      ...keyedSchema,
      message: z.string().min(1),
      meta: z.record(z.any()).optional(),
      close: z.boolean().optional(),
      fatal: z.boolean().optional()
    },
    async ({ conversation_key, job_id, message, meta, close, fatal }) => {
      try {
        await pushLegacyEvent({
          conversation_key,
          job_id,
          type: 'error',
          message,
          meta: meta || null,
          close: close ?? false,
          fatal: fatal === true
        });
        return okText(`error event sent`);
      } catch (error) {
        return errorText(error.message || 'failed to send error event');
      }
    }
  );

  server.tool(
    'send_webhook_result',
    {
      conversation_key: z.string().min(1),
      job_id: z.string().optional(),
      callback_url: z.string().optional(),
      delivery_status: z.string().optional(),
      final_result: z.string().optional(),
      error: z.string().optional(),
      done: z.boolean().optional(),
      events_json: z.string().optional()
    },
    async ({ conversation_key, job_id, callback_url, delivery_status, final_result, error, done, events_json }) => {
      try {
        let events = [];
        if (events_json) {
          try {
            const parsed = JSON.parse(events_json);
            if (Array.isArray(parsed)) events = parsed;
          } catch {
            throw new Error('events_json must be valid JSON array');
          }
        }
        await sendWebhookResult({
          conversation_key,
          job_id,
          callback_url: callback_url || '',
          delivery_status: delivery_status || (error ? 'failed' : 'completed'),
          final_result: final_result || '',
          error: error || null,
          done: done !== false,
          events
        });
        return okText(`webhook result stored for ${conversation_key}`);
      } catch (error) {
        return errorText(error.message || 'failed to send webhook result');
      }
    }
  );

  server.tool(
    'push_demo_sequence',
    {
      conversation_key: z.string().min(1),
      job_id: z.string().optional()
    },
    async ({ conversation_key, job_id }) => {
      try {
        await acceptRun({ conversation_key, job_id });
        await pushLegacyEvent({ conversation_key, job_id, type: 'status', message: '正在检查 Android 注入点' });
        await pushLegacyEvent({ conversation_key, job_id, type: 'reasoning', message: '先核对 Android 与鸿蒙的桥接入口，再确认方法列表是否一致。' });
        await pushLegacyEvent({ conversation_key, job_id, type: 'tool', message: 'read_file: android/WebViewBridge.java' });
        await pushLegacyEvent({ conversation_key, job_id, type: 'delta', text: '发现 Android 默认注入对象为 loan' });
        await pushLegacyEvent({ conversation_key, job_id, type: 'reasoning', message: '两端暴露的方法已对齐，接着确认分流规则和目标地址常量。' });
        await sendWebhookResult({
          conversation_key,
          job_id,
          delivery_status: 'completed',
          final_result: '结论：鸿蒙桥接已基本按 Android 迁移',
          done: true,
          events: [
            { type: 'status', title: '状态', text: '正在检查 Android 注入点', time: now() },
            { type: 'reasoning', title: '过程摘要', text: '先核对 Android 与鸿蒙的桥接入口，再确认方法列表是否一致。', time: now() },
            { type: 'delta', title: '阶段结果', text: '发现 Android 默认注入对象为 loan', time: now() },
            { type: 'final', title: '最终结果', text: '结论：鸿蒙桥接已基本按 Android 迁移', time: now() }
          ]
        });
        return okText(`demo sequence sent for ${conversation_key}`);
      } catch (error) {
        return errorText(error.message || 'failed to send demo sequence');
      }
    }
  );

  return server;
}

async function main() {
  const [{ McpServer }, { StreamableHTTPServerTransport }, { isInitializeRequest }, { z }] = await Promise.all([
    import('@modelcontextprotocol/sdk/server/mcp.js'),
    import('@modelcontextprotocol/sdk/server/streamableHttp.js'),
    import('@modelcontextprotocol/sdk/types.js'),
    import('zod')
  ]);

  const sessions = new Map();

  const server = http.createServer(async (req, res) => {
    const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, mcp-session-id',
        'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS'
      });
      return res.end();
    }

    if (req.method === 'GET' && urlObj.pathname === '/healthz') {
      return json(res, 200, {
        ok: true,
        service: 'agent-sse-mcp-server',
        now: now(),
        host: HOST,
        port: PORT,
        result_server_base_url: RESULT_SERVER_BASE_URL,
        public_mcp_url: PUBLIC_MCP_URL || null,
        active_sessions: sessions.size
      });
    }

    if (req.method === 'GET' && urlObj.pathname === '/.well-known/mcp.json') {
      return json(res, 200, {
        name: 'agent-result-callback-tools',
        description: 'Remote MCP callback tools for webhook-friendly status updates and final result delivery.',
        transport: {
          type: 'streamable-http',
          url: PUBLIC_MCP_URL || `http://${HOST}:${PORT}/mcp`
        },
        authentication: CALLBACK_MCP_AUTH_TOKEN ? { type: 'bearer' } : { type: 'none' }
      });
    }

    if (req.method === 'GET' && urlObj.pathname === '/') {
      return json(res, 200, {
        ok: true,
        service: 'agent-sse-mcp-server',
        endpoints: {
          healthz: 'GET /healthz',
          manifest: 'GET /.well-known/mcp.json',
          mcp: 'POST /mcp'
        },
        note: 'Expose this endpoint through a public tunnel and add it as a Custom MCP app.'
      });
    }

    if (urlObj.pathname !== '/mcp') {
      return json(res, 404, { ok: false, error: 'not_found' });
    }

    if (!isAuthorized(req)) {
      return json(res, 401, { ok: false, error: 'unauthorized' });
    }

    if (req.method === 'DELETE') {
      const sessionId = String(req.headers['mcp-session-id'] || '');
      const existing = sessions.get(sessionId);
      if (existing) {
        try { await existing.transport.close(); } catch (_) {}
        sessions.delete(sessionId);
      }
      return json(res, 200, { ok: true, closed: Boolean(existing), session_id: sessionId || null });
    }

    if (req.method !== 'POST') {
      return json(res, 405, { ok: false, error: 'method_not_allowed' });
    }

    let bodyRaw;
    try {
      bodyRaw = await readBody(req);
    } catch (error) {
      return json(res, 413, { ok: false, error: error.message || 'read_body_failed' });
    }

    let body;
    try {
      body = bodyRaw ? JSON.parse(bodyRaw) : {};
    } catch {
      return json(res, 400, { ok: false, error: 'invalid_json' });
    }

    const sessionId = String(req.headers['mcp-session-id'] || '');
    let entry = sessionId ? sessions.get(sessionId) : null;

    if (!entry) {
      if (sessionId || !isInitializeRequest(body)) {
        return json(res, 400, { ok: false, error: 'unknown_or_missing_session' });
      }

      const toolServer = createToolServer(McpServer, z);
      let currentTransport = null;
      const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => randomUUID(),
        onsessioninitialized: (newSessionId) => {
          sessions.set(newSessionId, { server: toolServer, transport: currentTransport });
        }
      });
      currentTransport = transport;
      transport.onclose = async () => {
        if (transport.sessionId) sessions.delete(transport.sessionId);
        try { await toolServer.close(); } catch (_) {}
      };

      await toolServer.connect(transport);
      entry = { server: toolServer, transport };
    }

    try {
      await entry.transport.handleRequest(req, res, body);
    } catch (error) {
      console.error('[agent-sse-mcp-server] request failed:', error);
      if (!res.headersSent) {
        return json(res, 500, { ok: false, error: 'mcp_request_failed', message: error.message || String(error) });
      }
      res.end();
    }
  });

  server.listen(PORT, HOST, () => {
    console.error(`[agent-sse-mcp-server] listening on http://${HOST}:${PORT}`);
    console.error(`[agent-sse-mcp-server] result server: ${RESULT_SERVER_BASE_URL}`);
    console.error(`[agent-sse-mcp-server] legacy push target: ${LEGACY_PUSH_ENDPOINT}`);
    console.error(`[agent-sse-mcp-server] webhook target: ${WEBHOOK_ENDPOINT}`);
    console.error(`[agent-sse-mcp-server] MCP endpoint: ${PUBLIC_MCP_URL || `http://${HOST}:${PORT}/mcp`}`);
    console.error(`[agent-sse-mcp-server] auth: ${CALLBACK_MCP_AUTH_TOKEN ? 'Bearer token required' : 'disabled'}`);
  });
}

main().catch((error) => {
  console.error('[agent-sse-mcp-server] fatal error:', error);
  process.exit(1);
});
